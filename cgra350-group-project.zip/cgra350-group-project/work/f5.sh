#!/bin/bash

mkdir build
cd build
cmake ..
make VERBOSE=1