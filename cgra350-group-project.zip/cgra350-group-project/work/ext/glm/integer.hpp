/// @ref core
/// @file glm/integer.hpp

#include "detail/setup.hpp"

#pragma once

#include "detail/func_integer.hpp"
