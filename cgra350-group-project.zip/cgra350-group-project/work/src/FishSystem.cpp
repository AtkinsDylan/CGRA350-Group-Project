#include "FishSystem.hpp"
#include <random>
#include <glm/gtc/random.hpp> // For glm::linearRand if using GLM for random values

FishSystem::FishSystem(const std::string& objFilePath, GLuint shader, int fishCount) {
    // Initialize the fish within the bounding box
    for (int i = 0; i < fishCount; ++i) {
        FishModel fish(objFilePath, shader);

        // Generate random start positions and velocities within a range
        glm::vec3 startPosition = glm::vec3(
            glm::linearRand(-50.0f, 50.0f),
            glm::linearRand(-50.0f, 50.0f),
            glm::linearRand(-50.0f, 50.0f)
        );
        glm::vec3 startVelocity = glm::vec3(
            glm::linearRand(-10.0f, 10.0f),
            glm::linearRand(-10.0f, 10.0f),
            glm::linearRand(-10.0f, 10.0f)
        );

        float randomScale = glm::linearRand(0.5f, 1.5f);

        fish.setPosition(startPosition);
        fish.setVelocity(startVelocity);
        fish.setScale(randomScale);
        m_fish.push_back(fish);
    }

    m_boundingBoxMin = glm::vec3(-230.0f, -110.0f, -230.0f);
    m_boundingBoxMax = glm::vec3(230.0f, -30.0f, 230.0f);
}

void FishSystem::update(float deltaTime) {
    for (auto& fish : m_fish) {
        fish.update(deltaTime);

        // Add boundary checks and velocity inversion if fish hit the bounding box
        glm::vec3 pos = fish.getPosition();
        glm::vec3 vel = fish.getVelocity();

        for (int i = 0; i < 3; ++i) {
            if (pos[i] < m_boundingBoxMin[i] || pos[i] > m_boundingBoxMax[i]) {
                vel[i] = -vel[i];
                // Ensure the position is kept within bounds after velocity reversal
                pos[i] = glm::clamp(pos[i], m_boundingBoxMin[i], m_boundingBoxMax[i]);
            }
        }

        fish.setVelocity(vel);
        fish.setPosition(pos);
    }
}

void FishSystem::draw(const glm::mat4& view, const glm::mat4& proj) {
    for (auto& fish : m_fish) {
        fish.draw(view, proj);
    }
}
