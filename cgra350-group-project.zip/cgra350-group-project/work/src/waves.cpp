#include "waves.hpp"
#include "gerstner_wave.hpp"
#include <glm/gtc/constants.hpp>
#include <cmath>
#include <iostream>
#include <algorithm>

#include <glm/gtc/noise.hpp>

using namespace glm;

namespace cgra {

    OceanSurface::OceanSurface(int grid_size_, float wave_amplitude_, float wind_speed_, glm::vec2 offset_, float scalingFactor_)
        : grid_size(grid_size_), wave_amplitude(wave_amplitude_), wind_speed(wind_speed_), offset(offset_), scalingFactor(scalingFactor_) {

        //verticies for surface
        for (int i = 0; i < grid_size; ++i) {
            for (int j = 0; j < grid_size; ++j) {
                vertices.push_back(vec3(i + offset.x, 0, j + offset.y));
            }
        }

        //indicies for surface
        for (int i = 0; i < grid_size - 1; ++i) {
            for (int j = 0; j < grid_size - 1; ++j) {
                int topLeft = i * grid_size + j;
                int topRight = topLeft + 1;
                int bottomLeft = topLeft + grid_size;
                int bottomRight = bottomLeft + 1;

                indices.push_back(topLeft);
                indices.push_back(bottomLeft);
                indices.push_back(bottomRight);

                indices.push_back(topLeft);
                indices.push_back(bottomRight);
                indices.push_back(topRight);
            }
        }
    }

    void OceanSurface::update(float time) {
        std::vector<vec2> wave_directions = {
            normalize(vec2(1.0f, 0.34f)),
            normalize(vec2(0.54f, 0.87f)),
            normalize(vec2(1.0f, 1.0f)),
            normalize(vec2(-0.5f, 0.543f)),
            normalize(vec2(-1.0f, -0.32f)),
            normalize(vec2(0.9f, -0.2f))
        };

        std::vector<float> baseWavelengths = {
            101.67f,
            102.67f,
            71.67f,
            123.67f,
            131.67f,
            83.67f
        };

        std::vector<float> baseAmplitudes = {
            wave_amplitude,
            wave_amplitude * 1.7f,
            wave_amplitude * 0.7f,
            wave_amplitude * 2.2f,
            wave_amplitude * 1.8f,
            wave_amplitude * 2.6f
        };

        std::vector<float> speeds = {
            wind_speed * 0.4f,
            wind_speed * 0.05f,
            wind_speed * 0.2f,
            wind_speed * 0.3f,
            wind_speed * 0.5f,
            wind_speed * 0.45f
        };

        std::vector<float> wavelengths;
        for (float baseWavelength : baseWavelengths) {
            wavelengths.push_back(baseWavelength * scalingFactor);
        }

        std::vector<float> amplitudes;
        for (float baseAmplitudes : baseAmplitudes) {
            amplitudes.push_back(baseAmplitudes * scalingFactor);
        }

        std::transform(wavelengths.begin(), wavelengths.end(), wavelengths.begin(),
            [this](float val) { return val * wavelengthScale; });

        std::transform(amplitudes.begin(), amplitudes.end(), amplitudes.begin(),
            [this](float val) { return val * amplitudeScale; });

        std::transform(speeds.begin(), speeds.end(), speeds.begin(),
            [this](float val) { return val * speedScale; });

        //height of vertex based on gerstner wave
        for (int i = 0; i < grid_size; ++i) {
            for (int j = 0; j < grid_size; ++j) {
                int index = i * grid_size + j;
                vec3& vertex = vertices[index];
                vertex.y = gerstner_wave(vertex.x, vertex.z, time, wave_directions, wavelengths, amplitudes, speeds).y;
            }
        }

        normals = calculateNormals();
    }

    std::vector<glm::vec3> OceanSurface::calculateNormals() const {
        std::vector<glm::vec3> normals(vertices.size(), glm::vec3(0.0f, 0.0f, 0.0f));

        for (int i = 0; i < grid_size - 1; ++i) {
            for (int j = 0; j < grid_size - 1; ++j) {
                //indicies
                int topLeft = i * grid_size + j;
                int topRight = topLeft + 1;
                int bottomLeft = topLeft + grid_size;
                int bottomRight = bottomLeft + 1;

                //verticies
                glm::vec3 v0 = vertices[topLeft];
                glm::vec3 v1 = vertices[bottomLeft];
                glm::vec3 v2 = vertices[topRight];

                //two triangle edges
                glm::vec3 edge1 = v1 - v0;
                glm::vec3 edge2 = v2 - v0;

                //cross product to get normal of edges
                glm::vec3 normal = glm::normalize(glm::cross(edge1, edge2));

                normals[topLeft] += normal;
                normals[bottomLeft] += normal;
                normals[topRight] += normal;

                //repeated for second triangle
                v0 = vertices[bottomRight];
                v1 = vertices[topRight];
                v2 = vertices[bottomLeft];

                edge1 = v1 - v0;
                edge2 = v2 - v0;

                normal = glm::normalize(glm::cross(edge1, edge2));

                normals[bottomRight] += normal;
                normals[topRight] += normal;
                normals[bottomLeft] += normal;
            }
        }

        for (auto& normal : normals) {
            normal = glm::normalize(normal);
        }

        return normals;
    }

    void OceanSurface::setOffset(glm::vec2 newOffset) {
        glm::vec2 delta = newOffset - offset;
        offset = newOffset;

        for (int i = 0; i < vertices.size(); ++i) {
            vertices[i].x += delta.x;
            vertices[i].z += delta.y;
        }
    }

    std::vector<vec3> OceanSurface::getVertices() const {
        return vertices;
    }

    std::vector<unsigned int> OceanSurface::getIndices() const {
        return indices;
    }

}
