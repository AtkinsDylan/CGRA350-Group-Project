#pragma once

#include <glm/glm.hpp>
#include <vector>

glm::vec3 gerstner_wave(float x, float z, float time, const std::vector<glm::vec2>& wave_directions, const std::vector<float>& wavelengths, const std::vector<float>& amplitudes, const std::vector<float>& speeds);
