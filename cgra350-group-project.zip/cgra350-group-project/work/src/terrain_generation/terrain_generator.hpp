#ifndef TERRAIN_GENERATOR_HPP
#define TERRAIN_GENERATOR_HPP

// std
#include <iostream>
#include <string>
#include <chrono>

// glm
#include <glm/gtc/constants.hpp>
#include <glm/gtc/matrix_transform.hpp>

// project
#include "application.hpp"
#include "cgra/cgra_geometry.hpp"
#include "cgra/cgra_gui.hpp"
#include "cgra/cgra_image.hpp"
#include "cgra/cgra_shader.hpp"
#include "cgra/cgra_wavefront.hpp"


using namespace std;
using namespace cgra;
using namespace glm;

class TerrainGenerator {
public:

	GLuint generateTerrain2D(int width, int height, int octaves, float persistence, float lacunarity, float amplitude, float frequency, float scale);
	gl_mesh generateTerrain3D(int spacing, int heightScale, int offset);
	void setDrawingMode(GLenum mode);
	void setShader(GLuint shader);
	void applyTexture(string texture_path, string normal_map_path);
	vector<mesh_vertex> getVertices();

private:

	vector<float> noiseData;
	int width, height, octaves;
	float persistence, lacunarity, amplitude, frequency, scale;
	GLenum customDrawingMode = GL_TRIANGLES;

	GLuint shader;
	GLuint texture;
	GLuint normal_map;
	bool textureLoaded = false;
	vector<mesh_vertex> terrainVertices;

	vector<float> generatePerlinNoise();
	GLuint displayTerrain2D(vector<float> noiseData);
	int getRandomSeed();
};

#endif // TERRAIN_GENERATOR_HPP