// std
#include <iostream>
#include <string>
#include <chrono>
#include <random>

// glm
#include <glm/gtc/constants.hpp>
#include <glm/gtc/matrix_transform.hpp>

// external libraries
#include <FastNoiseLite.h>

// project
#include "application.hpp"
#include "cgra/cgra_geometry.hpp"
#include "cgra/cgra_gui.hpp"
#include "cgra/cgra_image.hpp"
#include "cgra/cgra_shader.hpp"
#include "cgra/cgra_wavefront.hpp"

#include "terrain_generator.hpp"


using namespace std;
using namespace cgra;
using namespace glm;

GLuint TerrainGenerator::generateTerrain2D(int w, int h, int o, float p, float l, float a, float f, float s) {
	width = w, height = h;
	octaves = o, persistence = p, lacunarity = l, amplitude = a, frequency = f, scale = s;

	noiseData = generatePerlinNoise();
	return displayTerrain2D(noiseData);
}

gl_mesh TerrainGenerator::generateTerrain3D(int spacing, int heightScale, int offset) {

	mesh_builder builder;
	float widthDifference = (width * spacing) / 2;
	float heightDifference = (height * spacing) / 2;
	terrainVertices.clear();

	// Calculate vertexes
	for (int y = 0; y < height; ++y) {
		for (int x = 0; x < width; ++x) {
			int index = y * width + x;

			// Calculate vertex position
			float xCoord = (x * spacing) - heightDifference;
			float yCoord = (y * spacing) - widthDifference;
			float zCoord = noiseData[index] * spacing * heightScale;

			vec3 tangent = vec3(1, 0, 0);
			vec3 bitangent = vec3(0, 0, 1);

			float tilingFactor = 5.0f;
			vec2 uv = vec2(x / (float)width * tilingFactor, y / (float)height * tilingFactor);

			builder.vertices.push_back({ vec3(xCoord, zCoord + offset, yCoord), vec3(0, 0, 0), uv, tangent, bitangent });
			terrainVertices.push_back({ vec3(xCoord, zCoord + offset, yCoord), vec3(0, 0, 0), uv, tangent, bitangent });
		}
	}

	// Calculate normals
	for (int y = 0; y < height; ++y) {
		for (int x = 0; x < width; ++x) {

			vec3 normal;
			int index = y * width + x;

			if (y == height - 1 && x != width - 1) {
				normal = -builder.vertices[index - width].norm;
			}
			else if (x == width - 1 && y != height - 1) {
				normal = -builder.vertices[index - 1].norm;
			}
			else if (y == height - 1 && x == width - 1) {
				normal = -builder.vertices[index - width - 1].norm;
			}
			else {
				vec3 p0 = builder.vertices[index].pos;
				vec3 p1 = builder.vertices[index + 1].pos;
				vec3 p2 = builder.vertices[index + width].pos;
				vec3 p3 = builder.vertices[index + width + 1].pos;

				vec3 v1 = p1 - p0;
				vec3 v2 = p2 - p0;

				normal = normalize(cross(v1, v2));
			}

			builder.vertices[index].norm = -normal;
		}
	}

	// Calculate indicies
	for (int y = 0; y < height - 1; ++y) {
		for (int x = 0; x < width - 1; ++x) {

			int topLeft = y * width + x;
			int topRight = topLeft + 1;
			int bottomLeft = (y + 1) * width + x;
			int bottomRight = bottomLeft + 1;

			// First triangle
			builder.indices.push_back(topLeft);
			builder.indices.push_back(bottomLeft);
			builder.indices.push_back(topRight);

			// Second triangle
			builder.indices.push_back(topRight);
			builder.indices.push_back(bottomLeft);
			builder.indices.push_back(bottomRight);
		}
	}

	builder.mode = customDrawingMode;
	return builder.build();
}

vector<float> TerrainGenerator::generatePerlinNoise() {

	FastNoiseLite noise;
	noise.SetNoiseType(FastNoiseLite::NoiseType_Perlin);
	noise.SetSeed(getRandomSeed());
	vector<float> data(width * height);
	int index = 0;

	for (int y = 0; y < height; y++)
	{
		for (int x = 0; x < width; x++)
		{
			float local_amplitude = amplitude;
			float local_frequency = frequency;
			float noiseHeight = 0.0f;
			float maxValue = 0.0f;

			for (int i = 0; i < octaves; i++) {
				float sampleX = x / scale * local_frequency;
				float sampleY = y / scale * local_frequency;

				float perlinValue = noise.GetNoise(sampleX, sampleY);
				noiseHeight += perlinValue * local_amplitude;

				maxValue += local_amplitude;
				local_amplitude *= persistence;
				local_frequency *= lacunarity;
			}

			data[index++] = std::max(0.0f, std::min(1.0f, noiseHeight));
		}
	}

	return data;
}

GLuint TerrainGenerator::displayTerrain2D(vector<float> noiseData) {
	GLuint noiseTexture;
	vector<unsigned char> textureData(width * height * 4);

	// Convert noise to 2D texture
	for (int y = 0; y < height; ++y) {
		for (int x = 0; x < width; ++x) {
			int index = y * width + x;
			float noiseValue = noiseData[index];

			unsigned char colour = static_cast<unsigned char>(noiseValue * 255);

			textureData[index * 4] = colour;	 // R 
			textureData[index * 4 + 1] = colour; // G
			textureData[index * 4 + 2] = colour; // B
			textureData[index * 4 + 3] = 255;	 // A
		}
	}

	// Bind textures
	glGenTextures(1, &noiseTexture);
	glBindTexture(GL_TEXTURE_2D, noiseTexture);
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, textureData.data());
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

	return noiseTexture;
}

int TerrainGenerator::getRandomSeed() {

	std::random_device rd;
	std::mt19937 gen(rd());
	std::uniform_int_distribution<> distr(1, 1000);

	int random_number = distr(gen);

	return random_number;
}

void TerrainGenerator::setDrawingMode(GLenum mode) {
	customDrawingMode = mode;
}

void TerrainGenerator::setShader(GLuint s) {
	shader = s;
}

void TerrainGenerator::applyTexture(string texture_path, string normal_map_path) {
	if (!textureLoaded) {
		cgra::rgba_image base_texture(texture_path);
		texture = base_texture.uploadTexture();

		cgra::rgba_image normal(normal_map_path);
		normal_map = normal.uploadTexture();
		textureLoaded = true;
		cout << "Terrain Texture loaded" << endl;
	}

	glUseProgram(shader);

	glActiveTexture(GL_TEXTURE0);
	glBindTexture(GL_TEXTURE_2D, texture);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	glUniform1i(glGetUniformLocation(shader, "uTexture"), 0);

	glActiveTexture(GL_TEXTURE1);
	glBindTexture(GL_TEXTURE_2D, normal_map);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	glUniform1i(glGetUniformLocation(shader, "uNormalMap"), 1);

	glUniform1i(glGetUniformLocation(shader, "useTexture"), true);
}

vector<mesh_vertex> TerrainGenerator::getVertices() {
	return terrainVertices;
}