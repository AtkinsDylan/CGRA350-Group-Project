#ifndef PLANT_GENERATOR_HPP
#define PLANT_GENERATOR_HPP

#include <iostream>
#include <string>
#include <chrono>
#include <map>
#include <functional>
#include <vector>

// glm
#include <glm/gtc/constants.hpp>
#include <glm/gtc/matrix_transform.hpp>

// project
#include "application.hpp"
#include "cgra/cgra_geometry.hpp"
#include "cgra/cgra_gui.hpp"
#include "cgra/cgra_image.hpp"
#include "cgra/cgra_shader.hpp"
#include "cgra/cgra_wavefront.hpp"

struct basic_model;

typedef std::function<void(mat4&, vector<mat4>&)> FunctionPtr;

using namespace std;
using namespace cgra;
using namespace glm;

class PlantGenerator {
private:
	map<string, string> rules = {
	{"X", "F+[[X]-X]-F[-FX]+X"},
	{"F", "FF"},
	};

	map<string, FunctionPtr> drawRules;

	string startingWord = "X";
	string processWord(string word);

	void draw(mat4 drawTransform, string word);
	void drawForward(mat4& parentTransform, vector<mat4>& stack);
	void turnLeft(mat4& parentTransform, vector<mat4>& stack);
	void turnRight(mat4& parentTransform, vector<mat4>& stack);
	void pushState(mat4& parentTransform, vector<mat4>& stack);
	void popState(mat4& parentTransform, vector<mat4>& stack);

	int branch_length = 1;
	GLuint shader = 0;
	GLuint texture = 0;
	GLuint normal_map = 0;
	bool textureLoaded = false;

	vector<mat4> instanceTransforms;
	int instances = 0;

public:
	PlantGenerator() {
		drawRules["F"] = [this](mat4& m, vector<mat4>& stack) { drawForward(m, stack); };
		drawRules["+"] = [this](mat4& m, vector<mat4>& stack) { turnLeft(m, stack); };
		drawRules["-"] = [this](mat4& m, vector<mat4>& stack) { turnRight(m, stack); };
		drawRules["["] = [this](mat4& m, vector<mat4>& stack) { pushState(m, stack); };
		drawRules["]"] = [this](mat4& m, vector<mat4>& stack) { popState(m, stack); };
	}


	basic_model generateAndPlacePlants(int iterations, float length, TerrainGenerator terrain, int density, vec2 scaleRange);
	void applyTexture(string texture_path, string normal_map_path);
	void setShader(GLuint s);
};

#endif // PLANT_GENERATOR_HPP