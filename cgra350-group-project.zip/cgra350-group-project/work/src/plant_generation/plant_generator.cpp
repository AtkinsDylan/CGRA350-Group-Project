#include <iostream>
#include <string>
#include <chrono>
#include <random>
#include <tuple>

// glm
#include <glm/gtc/constants.hpp>
#include <glm/gtc/matrix_transform.hpp>

// project
#include "application.hpp"
#include "cgra/cgra_geometry.hpp"
#include "cgra/cgra_gui.hpp"
#include "cgra/cgra_image.hpp"
#include "cgra/cgra_shader.hpp"
#include "cgra/cgra_wavefront.hpp"

#include "plant_generation/plant_generator.hpp"

std::random_device rd;
std::mt19937 gen(rd());

using namespace std;
using namespace cgra;
using namespace glm;

string PlantGenerator::processWord(string word) {
	string newWord = "";

	for (int i = 0; i < word.length(); i++) {
		string c = word.substr(i, 1);

		if (rules.find(c) != rules.end()) {
			newWord += rules[c];
		}
		else {
			newWord += c;
		}
	}

	return newWord;
}

void PlantGenerator::drawForward(mat4& parentTransform, vector<mat4>& transformStack) {

	float scaleX = 0.5;
	float scaleY = 0.5;
	float scaleZ = 0.5;
	mat4 scaleMatrix = scale(glm::mat4(1.0f), glm::vec3(scaleX, scaleY, scaleZ));
	mat4 modelTransform = parentTransform * scaleMatrix;
	instanceTransforms.push_back(modelTransform);
	instances++;

	parentTransform = glm::translate(parentTransform, vec3(0, branch_length, 0));
}

void PlantGenerator::turnLeft(mat4& parentTransform, vector<mat4>& transformStack) {
	uniform_real_distribution<float> dis(10, 40);
	float rotation = dis(gen);

	parentTransform = rotate(parentTransform, radians(rotation), vec3(0, rand() % 2, 1));
}
void PlantGenerator::turnRight(mat4& parentTransform, vector<mat4>& transformStack) {
	uniform_real_distribution<float> dis(10, 40);
	float rotation = -dis(gen);

	parentTransform = rotate(parentTransform, radians(rotation), vec3(0, rand() % 2, 1));
}
void PlantGenerator::pushState(mat4& parentTransform, vector<mat4>& transformStack) {
	transformStack.push_back(parentTransform);
}
void PlantGenerator::popState(mat4& parentTransform, vector<mat4>& transformStack) {
	if (!transformStack.empty()) {
		parentTransform = transformStack.back();
		transformStack.pop_back();
	}
}

void PlantGenerator::draw(mat4 drawTransform, string word) {

	mat4 newTransform = drawTransform;
	vector<mat4> transformStack;

	for (int i = 0; i < word.length(); i++) {
		string c = word.substr(i, 1);
		if (drawRules.find(c) != drawRules.end()) {
			drawRules[c](newTransform, transformStack);
		}
	}
}

basic_model PlantGenerator::generateAndPlacePlants(int iterations, float length, TerrainGenerator terrain, int density, vec2 scaleRange) {

	instanceTransforms.clear();
	instances = 0;
	branch_length = length;

	for (int num = 0; num < density; num++) {

		// Set random vertex from terrain
		uniform_int_distribution<> dis2(0, terrain.getVertices().size() - 1);
		int randomIndex = dis2(gen);

		vec3 vertex = terrain.getVertices()[randomIndex].pos;

		mat4 drawTransform = mat4(1.0f);

		// Apply translation first
		drawTransform = translate(drawTransform, vertex);

		// Set random rotation
		uniform_real_distribution<float> dis3(0, 360);
		float randomRotationY = dis3(gen);
		drawTransform = rotate(drawTransform, radians(randomRotationY), vec3(0, 1, 0));

		// Set random scale
		uniform_real_distribution<float> dis1(scaleRange.x, scaleRange.y);
		float randomScale = dis1(gen);

		drawTransform = scale(drawTransform, vec3(randomScale));

		// Process the L-system word and draw the plant
		string word = startingWord;

		for (int i = 0; i < iterations; i++) {
			word = processWord(word);
		}

		draw(drawTransform, word);
	}

	basic_model sectionInstance;
	sectionInstance.shader = shader;

	mesh_builder builder = load_wavefront_data(CGRA_SRCDIR + string("/res/assets/seaweed_section2.obj"));
	builder.numInstances = instances;
	builder.instanceTransforms = instanceTransforms;

	sectionInstance.mesh = builder.build();
	sectionInstance.modelTransform = mat4(1.0f);

	sectionInstance.numInstances = instances;

	return sectionInstance;
}

void PlantGenerator::applyTexture(string texture_path, string normal_map_path) {
	if (shader == 0) {
		std::cerr << "Error: Shader has not been set!" << std::endl;
		return;
	}

	if (!textureLoaded) {
		cgra::rgba_image base_texture(texture_path);
		texture = base_texture.uploadTexture();

		cgra::rgba_image normal(normal_map_path);
		normal_map = normal.uploadTexture();
		textureLoaded = true;
		cout << "Plant Texture loaded" << endl;
	}

	glUseProgram(shader);

	glActiveTexture(GL_TEXTURE0);
	glBindTexture(GL_TEXTURE_2D, texture);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	glUniform1i(glGetUniformLocation(shader, "uTexture"), 0);

	glActiveTexture(GL_TEXTURE1);
	glBindTexture(GL_TEXTURE_2D, normal_map);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	glUniform1i(glGetUniformLocation(shader, "uNormalMap"), 1);
	glUniform1i(glGetUniformLocation(shader, "useTexture"), true);
}

void PlantGenerator::setShader(GLuint s) {
	if (s == 0) {
		std::cerr << "Warning: Attempting to set invalid shader program" << std::endl;
		return;
	}

	shader = s;
}