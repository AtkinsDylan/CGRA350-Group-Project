#pragma once

#include <glm/glm.hpp>
#include "cgra/cgra_mesh.hpp"

// Class for managing individual fish models
class FishModel {
private:
    cgra::gl_mesh m_mesh;
    glm::vec3 m_position;
    glm::vec3 m_velocity;
    glm::mat4 m_modelTransform;
    GLuint m_shader;
    float m_scale;

public:
    FishModel(const std::string& objFilePath, GLuint shader); // Include shader as a parameter
    void update(float deltaTime);
    void draw(const glm::mat4& view, const glm::mat4& proj);
    void setPosition(const glm::vec3& position);
    void setVelocity(const glm::vec3& velocity);
    // Getter methods to access position and velocity
    glm::vec3 getPosition() const { return m_position; }
    glm::vec3 getVelocity() const { return m_velocity; }
    void setScale(float scale);
};

