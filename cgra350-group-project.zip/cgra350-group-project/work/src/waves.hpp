#pragma once

#include <glm/glm.hpp>
#include <vector>

using namespace std;

namespace cgra {

    class OceanSurface {
    private:
        int grid_size;
        float wave_amplitude;
        float wind_speed;
        float scalingFactor;
        std::vector<glm::vec3> vertices;
        std::vector<unsigned int> indices;
        std::vector<glm::vec3> normals;
        glm::vec2 offset;
        float amplitudeScale = 1.0f;
        float speedScale = 1.0f;
        float wavelengthScale = 1.0f;

    public:
        OceanSurface(int grid_size, float wave_amplitude, float wind_speed, glm::vec2 offset, float scalingFactor);

        void update(float time);

        std::vector<glm::vec3> getVertices() const;
        std::vector<glm::vec3> calculateNormals() const;
        std::vector<unsigned int> getIndices() const;
        void setAmplitudeScale(float scale) { amplitudeScale = scale; }
        void setSpeedScale(float scale) { speedScale = scale; }
        void setWavelengthScale(float scale) { wavelengthScale = scale; }
        void setOffset(glm::vec2 newOffset);

    };
}