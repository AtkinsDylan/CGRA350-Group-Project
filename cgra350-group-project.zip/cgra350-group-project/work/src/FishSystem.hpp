#pragma once

#include <vector>
#include <glm/glm.hpp>
#include "FishModel.hpp"

// Class for managing a collection of fish
class FishSystem {
private:
    std::vector<FishModel> m_fish;
    glm::vec3 m_boundingBoxMin;
    glm::vec3 m_boundingBoxMax;

public:
    FishSystem(const std::string& objFilePath, GLuint shader, int fishCount);
    void update(float deltaTime);
    void draw(const glm::mat4& view, const glm::mat4& proj);
};
