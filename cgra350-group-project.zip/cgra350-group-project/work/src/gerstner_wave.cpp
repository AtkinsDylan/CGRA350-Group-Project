#include "gerstner_wave.hpp"
#include <glm/gtc/constants.hpp>

glm::vec3 gerstner_wave(float x, float z, float time, const std::vector<glm::vec2>& wave_directions,
    const std::vector<float>& wavelengths, const std::vector<float>& amplitudes, const std::vector<float>& speeds) {

    glm::vec3 total_displacement(0.0f);

    for (size_t i = 0; i < wave_directions.size(); ++i) {
        float k = 2.0f * glm::pi<float>() / wavelengths[i];
        float phase = glm::dot(wave_directions[i], glm::vec2(x, z)) * k - speeds[i] * time;
        float displacement = amplitudes[i] * glm::sin(phase);

        total_displacement.y += displacement;
    }

    return total_displacement;
}
