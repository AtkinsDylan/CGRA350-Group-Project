#include "ocean_volume.hpp"
#include "gerstner_wave.hpp"
#include <glm/gtc/constants.hpp>
#include <vector>
#include <cmath>
#include <iostream>
#include <algorithm>

using namespace glm;

namespace cgra {

    OceanVolume::OceanVolume(int grid_size_, float wave_amplitude_, float wind_speed_, float depth_, glm::vec2 offset_, bool drawLeft_, bool drawRight_, bool drawTop_, bool drawBottom_, float scalingFactor_)
        : grid_size(grid_size_), wave_amplitude(wave_amplitude_), wind_speed(wind_speed_), depth(depth_), offset(offset_),
        drawLeft(drawLeft_), drawRight(drawRight_), drawTop(drawTop_), drawBottom(drawBottom_), scalingFactor(scalingFactor_) {

        //verticies for sides
        for (int i = 0; i < grid_size; ++i) {
            for (int j = 0; j < grid_size; ++j) {
                vertices.push_back(vec3(i + offset.x, -depth, j + offset.y));
            }
        }

        if (drawLeft) {
            for (int j = 0; j < grid_size; ++j) {
                vertices.push_back(vec3(offset.x, 0, j + offset.y));
                vertices.push_back(vec3(offset.x, -depth, j + offset.y));
            }
        }

        if (drawRight) {
            for (int j = 0; j < grid_size; ++j) {
                vertices.push_back(vec3(offset.x + grid_size - 1, 0, j + offset.y));
                vertices.push_back(vec3(offset.x + grid_size - 1, -depth, j + offset.y));
            }
        }

        if (drawTop) {
            for (int i = 0; i < grid_size; ++i) {
                vertices.push_back(vec3(i + offset.x, 0, offset.y));
                vertices.push_back(vec3(i + offset.x, -depth, offset.y));
            }
        }

        if (drawBottom) {
            for (int i = 0; i < grid_size; ++i) {
                vertices.push_back(vec3(i + offset.x, 0, offset.y + grid_size - 1));
                vertices.push_back(vec3(i + offset.x, -depth, offset.y + grid_size - 1));
            }
        }

        //indicies for sides
        int sideStartIndex = grid_size * grid_size;

        if (drawLeft) {
            for (int j = 0; j < grid_size - 1; ++j) {
                int surfaceTopLeft = sideStartIndex + j * 2;
                int surfaceBottomLeft = surfaceTopLeft + 1;
                int surfaceTopRight = surfaceTopLeft + 2;
                int surfaceBottomRight = surfaceBottomLeft + 2;

                indices.push_back(surfaceTopLeft);
                indices.push_back(surfaceBottomLeft);
                indices.push_back(surfaceBottomRight);

                indices.push_back(surfaceTopLeft);
                indices.push_back(surfaceBottomRight);
                indices.push_back(surfaceTopRight);
            }
            sideStartIndex += grid_size * 2;
        }

        if (drawRight) {
            for (int j = 0; j < grid_size - 1; ++j) {
                int surfaceTopLeft = sideStartIndex + j * 2;
                int surfaceBottomLeft = surfaceTopLeft + 1;
                int surfaceTopRight = surfaceTopLeft + 2;
                int surfaceBottomRight = surfaceBottomLeft + 2;

                indices.push_back(surfaceTopLeft);
                indices.push_back(surfaceBottomLeft);
                indices.push_back(surfaceBottomRight);

                indices.push_back(surfaceTopLeft);
                indices.push_back(surfaceBottomRight);
                indices.push_back(surfaceTopRight);
            }
            sideStartIndex += grid_size * 2;
        }

        if (drawTop) {
            for (int i = 0; i < grid_size - 1; ++i) {
                int surfaceTopLeft = sideStartIndex + i * 2;
                int surfaceBottomLeft = surfaceTopLeft + 1;
                int surfaceTopRight = surfaceTopLeft + 2;
                int surfaceBottomRight = surfaceBottomLeft + 2;

                indices.push_back(surfaceTopLeft);
                indices.push_back(surfaceBottomLeft);
                indices.push_back(surfaceBottomRight);

                indices.push_back(surfaceTopLeft);
                indices.push_back(surfaceBottomRight);
                indices.push_back(surfaceTopRight);
            }
            sideStartIndex += grid_size * 2;
        }

        if (drawBottom) {
            for (int i = 0; i < grid_size - 1; ++i) {
                int surfaceTopLeft = sideStartIndex + i * 2;
                int surfaceBottomLeft = surfaceTopLeft + 1;
                int surfaceTopRight = surfaceTopLeft + 2;
                int surfaceBottomRight = surfaceBottomLeft + 2;

                indices.push_back(surfaceTopLeft);
                indices.push_back(surfaceBottomLeft);
                indices.push_back(surfaceBottomRight);

                indices.push_back(surfaceTopLeft);
                indices.push_back(surfaceBottomRight);
                indices.push_back(surfaceTopRight);
            }
        }
    }

    std::vector<vec3> OceanVolume::getVertices() const {
        return vertices;
    }

    std::vector<unsigned int> OceanVolume::getIndices() const {
        return indices;
    }

    void OceanVolume::update(float time) {
        std::vector<vec2> wave_directions = {
            normalize(vec2(1.0f, 0.34f)),
            normalize(vec2(0.54f, 0.87f)),
            normalize(vec2(1.0f, 1.0f)),
            normalize(vec2(-0.5f, 0.543f)),
            normalize(vec2(-1.0f, -0.32f)),
            normalize(vec2(0.9f, -0.2f))
        };

        std::vector<float> baseWavelengths = {
            101.67f,
            102.67f,
            71.67f,
            123.67f,
            131.67f,
            83.67f
        };

        std::vector<float> baseAmplitudes = {
            wave_amplitude,
            wave_amplitude * 1.7f,
            wave_amplitude * 0.7f,
            wave_amplitude * 2.2f,
            wave_amplitude * 1.8f,
            wave_amplitude * 2.6f
        };

        std::vector<float> speeds = {
            wind_speed * 0.4f,
            wind_speed * 0.05f,
            wind_speed * 0.2f,
            wind_speed * 0.3f,
            wind_speed * 0.5f,
            wind_speed * 0.45f
        };

        std::vector<float> wavelengths;
        for (float baseWavelength : baseWavelengths) {
            wavelengths.push_back(baseWavelength * scalingFactor);
        }

        std::vector<float> amplitudes;
        for (float baseAmplitudes : baseAmplitudes) {
            amplitudes.push_back(baseAmplitudes * scalingFactor);
        }

        std::transform(wavelengths.begin(), wavelengths.end(), wavelengths.begin(),
            [this](float val) { return val * wavelengthScale; });

        std::transform(amplitudes.begin(), amplitudes.end(), amplitudes.begin(),
            [this](float val) { return val * amplitudeScale; });

        std::transform(speeds.begin(), speeds.end(), speeds.begin(),
            [this](float val) { return val * speedScale; });

        int sideStartIndex = grid_size * grid_size;

        if (drawLeft) {
            for (int j = 0; j < grid_size; ++j) {
                vec3& surfaceVertex = vertices[sideStartIndex + j * 2];
                surfaceVertex.y = gerstner_wave(surfaceVertex.x, surfaceVertex.z, time, wave_directions, wavelengths, amplitudes, speeds).y;
            }
            sideStartIndex += grid_size * 2;
        }

        if (drawRight) {
            for (int j = 0; j < grid_size; ++j) {
                vec3& surfaceVertex = vertices[sideStartIndex + j * 2];
                surfaceVertex.y = gerstner_wave(surfaceVertex.x, surfaceVertex.z, time, wave_directions, wavelengths, amplitudes, speeds).y;
            }
            sideStartIndex += grid_size * 2;
        }

        if (drawTop) {
            for (int i = 0; i < grid_size; ++i) {
                vec3& surfaceVertex = vertices[sideStartIndex + i * 2];
                surfaceVertex.y = gerstner_wave(surfaceVertex.x, surfaceVertex.z, time, wave_directions, wavelengths, amplitudes, speeds).y;
            }
            sideStartIndex += grid_size * 2;
        }

        if (drawBottom) {
            for (int i = 0; i < grid_size; ++i) {
                vec3& surfaceVertex = vertices[sideStartIndex + i * 2];
                surfaceVertex.y = gerstner_wave(surfaceVertex.x, surfaceVertex.z, time, wave_directions, wavelengths, amplitudes, speeds).y;
            }
        }
    }

    void OceanVolume::setOffset(glm::vec2 newOffset) {
        glm::vec2 delta = newOffset - offset;
        offset = newOffset;

        for (int i = 0; i < vertices.size(); ++i) {
            vertices[i].x += delta.x;
            vertices[i].z += delta.y;
        }
    }



}
