#ifndef ROCK_GENERATOR_HPP
#define ROCK_GENERATOR_HPP

#include <iostream>
#include <string>
#include <chrono>
#include <map>
#include <functional>
#include <vector>
#include <random>

// glm
#include <glm/gtc/constants.hpp>
#include <glm/gtc/matrix_transform.hpp>

// project
#include "application.hpp"
#include "cgra/cgra_geometry.hpp"
#include "cgra/cgra_gui.hpp"
#include "cgra/cgra_image.hpp"
#include "cgra/cgra_shader.hpp"
#include "cgra/cgra_wavefront.hpp"

struct basic_model;

using namespace std;
using namespace cgra;
using namespace glm;

class RockGenerator {
private:

	vector<string> rockPaths;

	GLuint shader = 0;
	GLuint texture = 0;
	GLuint normal_map = 0;
	bool textureLoaded = false;

	static std::random_device rd;
	std::mt19937 gen;

public:
	RockGenerator() : gen(rd()) {}

	vector<basic_model> generateRocks(vector<string> paths, TerrainGenerator terrain, int density, vec2 scaleRange);
	void loadRock(mat4& parentTransform, vector<basic_model>& meshesToDraw);
	gl_mesh pickRandomRockMesh();
	void applyTexture(string texture_path, string normal_map_path);
	void setShader(GLuint s);
};

#endif