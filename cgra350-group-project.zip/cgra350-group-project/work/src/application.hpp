// application.hpp
#pragma once

#include <glm/glm.hpp>
#include <glm/gtc/type_ptr.hpp>

#include "opengl.hpp"
#include "cgra/cgra_mesh.hpp"
#include "skeleton_model.hpp"

#include "FishSystem.hpp"


// Forward declaration of OceanSurface
namespace cgra {
	class OceanSurface;
	class OceanVolume;
}

// custom
#include "terrain_generation/terrain_generator.hpp"
#include "plant_generation/plant_generator.hpp"
#include "rock_generator.hpp"

// Basic model that holds the shader, mesh, and transform for drawing.
struct basic_model {
	GLuint shader = 0;
	cgra::gl_mesh mesh;
	glm::vec3 color{ 0.0 };
	glm::mat4 modelTransform{ 1.0 };
	GLuint texture;
	int numInstances = 0;

	void draw(const glm::mat4& view, const glm::mat4 proj, bool isInstance);
};

struct model_group {
	string name;
	std::vector<basic_model> models;
};

// Main application class
class Application {
private:
	// window
	glm::vec2 m_windowsize;
	GLFWwindow* m_window;

	// orbital camera
	float m_pitch = .86;
	float m_yaw = -.86;
	float m_distance = 20;

	// last input
	bool m_leftMouseDown = false;
	glm::vec2 m_mousePosition;

	// drawing flags
	bool m_show_axis = false;
	bool m_show_grid = false;
	bool m_showWireframe = false;

	// geometry
	basic_model m_model;

	GLuint shader;

	GLuint shaderDefault;
	FishSystem m_fishSystem;

	//water variables
	std::vector<cgra::OceanSurface*> oceanSurfaces;
	std::vector<cgra::OceanVolume*> oceanVolumes;
	GLuint surfaceVAO, surfaceVBO, surfaceEBO;
	GLuint volumeVAO, volumeVBO, volumeEBO;
	GLuint normalVBO;
	GLuint texCoordVBO;
	GLuint underwaterVAO, underwaterVBO, underwaterEBO;
	GLuint oceanVolumeShader;
	GLuint oceanShader;
	glm::vec3 waterColor;
	glm::vec3 cameraPos;
	bool isUnderwater = false;

	float imGuiWindowLength = 400;
	float imGuiWindowHeight = 600;

	// Noise generation
	GLuint noiseTexture;
	bool noiseLoaded = false;

	int noise_size = 500;
	int noise_octaves = 4;
	float noise_persistence = 0.4f;
	float noise_lacunarity = 2.0f;
	float noise_amplitude = 1.0f;
	float noise_frequency = 1.0f;
	float noise_scale = 1.0;

	// Models to load
	std::vector<model_group> modelsToLoad;

	// Terrain generation
	TerrainGenerator terrainGenerator;
	std::vector<cgra::gl_mesh> terrainModels;
	int spacing = 1;
	int heightScaling = 30;
	int terrainOffset = -150;
	int selected_drawing_mode = 0;
	bool auto_generate_terrain = false;
	bool auto_generate_entire = false;
	string terrain_texture_path = CGRA_SRCDIR + std::string("/res/textures/Terrain_Texture.jpg");
	string terrain_normal_map_path = CGRA_SRCDIR + std::string("/res/textures/Terrain_NormalMap.jpg");

	// Plant Generation
	PlantGenerator plantGenerator;
	basic_model plantInstance;
	int iterations = 4;
	int branch_length = 1;
	int plant_density = 100;
	vec2 plant_scale_range = vec2(0.1, 1.0);
	vec3 plant_scale = vec3(0.5, 0.5, 0.5);
	vec3 plant_location = vec3(0.0, 0.0, 0.0);
	string seaweed_texture_path = CGRA_SRCDIR + std::string("/res/textures/Seaweed_Texture.jpg");
	string seaweed_normal_map_path = CGRA_SRCDIR + std::string("/res/textures/Seaweed_NormalMap.jpg");

	// Rock generation
	RockGenerator rockGenerator;
	int rock_density = 100;
	vec2 rock_scale_range = vec2(0.1, 1.0);
	vector<string> rock_paths = {
		"/res/assets/rock1.obj",
		"/res/assets/rock2.obj",
		"/res/assets/rock3.obj",
		"/res/assets/rock4.obj",
		"/res/assets/rock5.obj",
		"/res/assets/rock6.obj",
		"/res/assets/rock7.obj",
		"/res/assets/rock8.obj"
	};
	string rock_texture_path = CGRA_SRCDIR + std::string("/res/textures/Rock_Texture.jpg");
	string rock_normal_map_path = CGRA_SRCDIR + std::string("/res/textures/Rock_NormalMap.jpg");

public:
	// setup
	Application(GLFWwindow* window);

	// disable copy constructors
	Application(const Application&) = delete;
	Application& operator=(const Application&) = delete;

	// rendering callbacks (every frame)
	void render();
	void renderGUI();

	// input callbacks
	void cursorPosCallback(double xpos, double ypos);
	void mouseButtonCallback(int button, int action, int mods);
	void scrollCallback(double xoffset, double yoffset);
	void keyCallback(int key, int scancode, int action, int mods);
	void charCallback(unsigned int c);
	void removeMeshesFromRenderList(string name);
	void regenerateTerrain();
	void regeneratePlants();
	void regenerateRocks();

	double m_lastTime = 0.0;
};