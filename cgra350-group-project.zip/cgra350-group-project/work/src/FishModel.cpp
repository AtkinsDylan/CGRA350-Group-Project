#include "FishModel.hpp"
#include "cgra/cgra_shader.hpp" // Include shader builder if not already included
#include "cgra/cgra_wavefront.hpp" // For loading OBJ files
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>

FishModel::FishModel(const std::string& objFilePath, GLuint shader) : m_shader(shader), m_scale(1.0f) {
    // Build the shader using shader_builder
    cgra::shader_builder sb;
    sb.set_shader(GL_VERTEX_SHADER, CGRA_SRCDIR + std::string("/res/shaders/color_default_vert.glsl"));
    sb.set_shader(GL_FRAGMENT_SHADER, CGRA_SRCDIR + std::string("/res/shaders/color_default_frag.glsl"));
    m_shader = sb.build();

    // Load the mesh using load_wavefront_data and build it
    m_mesh = cgra::load_wavefront_data(objFilePath).build();
    m_position = glm::vec3(0.0f); // Initial position
    m_velocity = glm::vec3(0.0f); // Initial velocity
    m_modelTransform = glm::mat4(1.0f);
}

// Define the setScale method
void FishModel::setScale(float scale) {
    m_scale = scale;
}

void FishModel::update(float deltaTime) {
    // Update the fish's position using velocity and deltaTime
    m_position += m_velocity * deltaTime;

    // Normalize the velocity to get the direction
    glm::vec3 direction = glm::normalize(m_velocity);
    glm::vec3 forward = glm::vec3(0.0f, 0.0f, 1.0f);

    // Calculate the rotation needed to align the forward direction with the velocity direction
    glm::mat4 rotationMatrix = glm::mat4(1.0f);
    if (glm::length(direction) > 0.001f) {
        glm::vec3 rotationAxis = glm::cross(forward, direction);
        float dotProduct = glm::dot(forward, direction);
        float angle = glm::acos(dotProduct);
        rotationMatrix = glm::rotate(glm::mat4(1.0f), angle, rotationAxis);
    }

    // Apply scaling, rotation, and translation to the model matrix
    glm::mat4 scaleMatrix = glm::scale(glm::mat4(1.0f), glm::vec3(m_scale));
    glm::mat4 translationMatrix = glm::translate(glm::mat4(1.0f), m_position);

    // Combine translation, rotation, and scaling matrices
    m_modelTransform = translationMatrix * rotationMatrix * scaleMatrix;
}

void FishModel::draw(const glm::mat4& view, const glm::mat4& proj) {
    glDisable(GL_CULL_FACE);
    glm::mat4 modelview = view * m_modelTransform;
    glUseProgram(m_shader); // Use the fish model's shader

    GLint projLocation = glGetUniformLocation(m_shader, "uProjectionMatrix");
    GLint modelViewLocation = glGetUniformLocation(m_shader, "uModelViewMatrix");

    if (projLocation != -1) {
        glUniformMatrix4fv(projLocation, 1, false, glm::value_ptr(proj));
    }
    if (modelViewLocation != -1) {
        glUniformMatrix4fv(modelViewLocation, 1, false, glm::value_ptr(modelview));
    }

    // Set color or any other uniforms specific to the fish model here, if needed
    glUniform3fv(glGetUniformLocation(m_shader, "uColor"), 1, glm::value_ptr(glm::vec3(0.2f, 0.8f, 0.5f))); // Example color

    m_mesh.draw(false,1); // Draw the fish mesh
}

void FishModel::setPosition(const glm::vec3& position) {
    m_position = position;
}

void FishModel::setVelocity(const glm::vec3& velocity) {
    m_velocity = velocity;
}