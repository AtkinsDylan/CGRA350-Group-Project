#include <iostream>
#include <string>
#include <chrono>
#include <random>
#include <tuple>

// glm
#include <glm/gtc/constants.hpp>
#include <glm/gtc/matrix_transform.hpp>

// project
#include "application.hpp"
#include "cgra/cgra_geometry.hpp"
#include "cgra/cgra_gui.hpp"
#include "cgra/cgra_image.hpp"
#include "cgra/cgra_shader.hpp"
#include "cgra/cgra_wavefront.hpp"

#include "rock_generator.hpp"

std::random_device RockGenerator::rd;

using namespace std;
using namespace cgra;
using namespace glm;


void RockGenerator::loadRock(mat4& parentTransform, vector<basic_model>& meshesToDraw) {

	basic_model rock;

	// Set transform
	float rock_scale = 10.0;
	mat4 scaleMatrix = scale(glm::mat4(1.0f), glm::vec3(rock_scale));
	rock.modelTransform = parentTransform * scaleMatrix;

	// Set other variables
	rock.shader = shader;
	rock.mesh = pickRandomRockMesh();

	meshesToDraw.push_back(rock);
}

gl_mesh RockGenerator::pickRandomRockMesh() {

	uniform_int_distribution<> dis2(0, rockPaths.size() - 1);
	int randomIndex = dis2(gen);
	string randomRockPath = CGRA_SRCDIR + rockPaths[randomIndex];
	gl_mesh rockMesh = load_wavefront_data(randomRockPath).build();

	return rockMesh;
}

vector<basic_model> RockGenerator::generateRocks(vector<string> paths, TerrainGenerator terrain, int density, vec2 scaleRange) {
	rockPaths = paths;
	vector<basic_model> rocks;

	for (int num = 0; num < density; num++) {

		// Set random vertex from terrain
		uniform_int_distribution<> dis2(0, terrain.getVertices().size() - 1);
		int randomIndex = dis2(gen);

		vec3 vertex = terrain.getVertices()[randomIndex].pos;

		mat4 drawTransform = mat4(1.0f);

		// Apply translation first
		drawTransform = translate(drawTransform, vertex);

		// Set random rotation
		uniform_real_distribution<float> dis3(0, 360);
		float randomRotationX = dis3(gen);
		float randomRotationY = dis3(gen);
		float randomRotationZ = dis3(gen);
		drawTransform = rotate(drawTransform, radians(randomRotationX), vec3(1, 0, 0));
		drawTransform = rotate(drawTransform, radians(randomRotationY), vec3(0, 1, 0));
		drawTransform = rotate(drawTransform, radians(randomRotationZ), vec3(0, 0, 1));

		// Set random scale
		uniform_real_distribution<float> dis1(scaleRange.x, scaleRange.y);
		float randomScale = dis1(gen);

		drawTransform = scale(drawTransform, vec3(randomScale));

		loadRock(drawTransform, rocks);
	}

	return rocks;
}

void RockGenerator::applyTexture(string texture_path, string normal_map_path) {
	if (shader == 0) {
		std::cerr << "Error: Shader has not been set!" << std::endl;
		return;
	}

	if (!textureLoaded) {
		cgra::rgba_image base_texture(texture_path);
		texture = base_texture.uploadTexture();

		cgra::rgba_image normal(normal_map_path);
		normal_map = normal.uploadTexture();
		textureLoaded = true;
		cout << "Rock Texture loaded" << endl;
	}

	glUseProgram(shader);

	glActiveTexture(GL_TEXTURE0);
	glBindTexture(GL_TEXTURE_2D, texture);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	glUniform1i(glGetUniformLocation(shader, "uTexture"), 0);

	glActiveTexture(GL_TEXTURE1);
	glBindTexture(GL_TEXTURE_2D, normal_map);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	glUniform1i(glGetUniformLocation(shader, "uNormalMap"), 1);
	glUniform1i(glGetUniformLocation(shader, "useTexture"), true);
}

void RockGenerator::setShader(GLuint s) {
	if (s == 0) {
		std::cerr << "Warning: Attempting to set invalid shader program" << std::endl;
		return;
	}

	shader = s;
}