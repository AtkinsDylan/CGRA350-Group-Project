// std
#include <iostream>
#include <string>
#include <chrono>
#include <random>

// glm
#include <glm/gtc/constants.hpp>
#include <glm/gtc/matrix_transform.hpp>

#include "waves.hpp"
#include "ocean_volume.hpp"

// project
#include "application.hpp"
#include "cgra/cgra_geometry.hpp"
#include "cgra/cgra_gui.hpp"
#include "cgra/cgra_image.hpp"
#include "cgra/cgra_shader.hpp"
#include "cgra/cgra_wavefront.hpp"
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>
#include "cgra/cgra_mesh.hpp"
#include "plant_generation/plant_generator.hpp"
#include "terrain_generation/terrain_generator.hpp"

using namespace std;
using namespace cgra;
using namespace glm;

GLuint oceanVAO, oceanVBO, oceanEBO;
GLuint oceanShader;

glm::vec3 lightPos(0.0f, 50.0f, -400.0f);
glm::vec3 lightColor(0.2f, 0.2f, 0.2f);

void basic_model::draw(const glm::mat4& view, const glm::mat4 proj, bool isInstance) {

	mat4 modelview = view * modelTransform;

	glUseProgram(shader);
	glUniformMatrix4fv(glGetUniformLocation(shader, "uProjectionMatrix"), 1, false, value_ptr(proj));
	glUniformMatrix4fv(glGetUniformLocation(shader, "uModelViewMatrix"), 1, false, value_ptr(modelview));
	glUniform3fv(glGetUniformLocation(shader, "uColor"), 1, value_ptr(color));
	glUniform1i(glGetUniformLocation(shader, "numInstances"), numInstances);

	mesh.draw(isInstance, numInstances);
}

GLuint foamTexture;

void loadFoamTexture() {

	glGenTextures(1, &foamTexture);
	glBindTexture(GL_TEXTURE_2D, foamTexture);

	// Load the foam texture
	int width, height, nrChannels;
	std::string path = CGRA_SRCDIR + std::string("//res//textures//seafoam.jpg");
	std::cout << "Loading texture from: " << path << std::endl;
	unsigned char* data = stbi_load(path.c_str(), &width, &height, &nrChannels, 0);

	if (data) {
		std::cout << "Foam texture loaded successfully!" << std::endl;

		// Upload the texture data to OpenGL
		glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, data);

		// Generate mipmaps to avoid warnings
		glGenerateMipmap(GL_TEXTURE_2D);

		// Set texture parameters (min and mag filters, wrap modes)
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	}
	else {
		std::cout << "Failed to load foam texture." << std::endl;
	}
	std::cout << "Foam Texture ID: " << foamTexture << std::endl;

	// Free image memory
	stbi_image_free(data);

	// Unbind the texture
	glBindTexture(GL_TEXTURE_2D, 0);
}


Application::Application(GLFWwindow* window) : m_window(window), m_fishSystem(CGRA_SRCDIR + std::string("//res//assets//GoldenFish.obj"), shaderDefault, 10) {

	//changed default shader
	shader_builder sb;
	sb.set_shader(GL_VERTEX_SHADER, CGRA_SRCDIR + std::string("//res//shaders//color_vert.glsl"));
	sb.set_shader(GL_FRAGMENT_SHADER, CGRA_SRCDIR + std::string("//res//shaders//color_frag.glsl"));
	shader = sb.build();

	m_model.shader = shader;

	//default shader
	shader_builder sbDefault;
	sbDefault.set_shader(GL_VERTEX_SHADER, CGRA_SRCDIR + std::string("//res//shaders//color_default_vert.glsl"));
	sbDefault.set_shader(GL_FRAGMENT_SHADER, CGRA_SRCDIR + std::string("//res//shaders//color_default_frag.glsl"));
	shaderDefault = sbDefault.build();

	m_lastTime = glfwGetTime();

	// Load noise on startup
	noiseTexture = terrainGenerator.generateTerrain2D(noise_size, noise_size, noise_octaves, noise_persistence, noise_lacunarity, noise_amplitude, noise_frequency, noise_scale);

	// Generate terrain on startup
	terrainGenerator.setShader(shader);
	regenerateTerrain();

	// Generate plants on startup
	plantGenerator.setShader(shader);
	regeneratePlants();

	// Generate rocks on startup
	rockGenerator.setShader(shader);
	regenerateRocks();

	//make grid of waves in 500 x 500 area
	int gridSize = 1;
	float tileSize = 500.0f / gridSize;

	for (int i = 0; i < gridSize; i++) {
		for (int j = 0; j < gridSize; j++) {
			bool drawLeft = (i == 0);
			bool drawRight = (i == gridSize - 1);
			bool drawTop = (j == 0);
			bool drawBottom = (j == gridSize - 1);

			float offsetX = -250 + (i * tileSize);
			float offsetY = -250 + (j * tileSize);

			oceanSurfaces.push_back(new OceanSurface(tileSize + 2.0f, 2.0f, 5.0f, glm::vec2(offsetX, offsetY), 1.0f));
			oceanVolumes.push_back(new OceanVolume(tileSize + 2.0f, 2.0f, 5.0f, 150.0f, glm::vec2(offsetX, offsetY), drawLeft, drawRight, drawTop, drawBottom, 1.0f));
		}
	}

	//ocean shader
	shader_builder sbOcean;
	sbOcean.set_shader(GL_VERTEX_SHADER, CGRA_SRCDIR + std::string("/res/shaders/ocean_volume_vert.glsl"));
	sbOcean.set_shader(GL_FRAGMENT_SHADER, CGRA_SRCDIR + std::string("/res/shaders/ocean_volume_frag.glsl"));
	oceanVolumeShader = sbOcean.build();

	//wave shader
	shader_builder sbWave;
	sbWave.set_shader(GL_VERTEX_SHADER, CGRA_SRCDIR + std::string("/res//shaders//ocean_vert.glsl"));
	sbWave.set_shader(GL_FRAGMENT_SHADER, CGRA_SRCDIR + std::string("/res//shaders//ocean_frag.glsl"));
	oceanShader = sbWave.build();

	waterColor = glm::vec3(0.0f, 0.2f, 0.4f);

	//underwater quad
	float quadVertices[] = {
		-1.0f,  1.0f, 0.0f,
		-1.0f, -1.0f, 0.0f,
		 1.0f, -1.0f, 0.0f,
		 1.0f,  1.0f, 0.0f
	};

	unsigned int quadIndices[] = { 0, 1, 2, 0, 2, 3 };

	//quad buffers
	glGenVertexArrays(1, &underwaterVAO);
	glGenBuffers(1, &underwaterVBO);
	glGenBuffers(1, &underwaterEBO);

	glBindVertexArray(underwaterVAO);

	glBindBuffer(GL_ARRAY_BUFFER, underwaterVBO);
	glBufferData(GL_ARRAY_BUFFER, sizeof(quadVertices), quadVertices, GL_STATIC_DRAW);

	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, underwaterEBO);
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(quadIndices), quadIndices, GL_STATIC_DRAW);

	glEnableVertexAttribArray(0);
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(float), (void*)0);

	glBindVertexArray(0);


	//surface buffers
	glGenVertexArrays(1, &surfaceVAO);
	glGenBuffers(1, &surfaceVBO);
	glGenBuffers(1, &surfaceEBO);
	glGenBuffers(1, &normalVBO);
	glGenBuffers(1, &texCoordVBO);

	glBindVertexArray(surfaceVAO);

	loadFoamTexture(); //loads the jpg texture for the water

	//get verticies, normals and set texture coordinates based on verticies
	std::vector<glm::vec3> vertices = oceanSurfaces[0]->getVertices();
	std::vector<glm::vec3> normals = oceanSurfaces[0]->calculateNormals();
	std::vector<glm::vec2> texCoords;
	for (const auto& vertex : vertices) {
		float u = (vertex.x + 250.0f) / 500.0f;
		float v = (vertex.z + 250.0f) / 500.0f;
		texCoords.push_back(glm::vec2(u, v));
	}

	//bind vertex data
	glBindBuffer(GL_ARRAY_BUFFER, surfaceVBO);
	glBufferData(GL_ARRAY_BUFFER, vertices.size() * sizeof(glm::vec3), vertices.data(), GL_DYNAMIC_DRAW);
	glEnableVertexAttribArray(0); // Position attribute at location 0
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(float), (void*)0);

	//bind normal data
	glBindBuffer(GL_ARRAY_BUFFER, normalVBO);
	glBufferData(GL_ARRAY_BUFFER, normals.size() * sizeof(glm::vec3), normals.data(), GL_DYNAMIC_DRAW);
	glEnableVertexAttribArray(1); // Normal attribute at location 1
	glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(float), (void*)0);

	//bind tex data
	glBindBuffer(GL_ARRAY_BUFFER, texCoordVBO);
	glBufferData(GL_ARRAY_BUFFER, texCoords.size() * sizeof(glm::vec2), texCoords.data(), GL_STATIC_DRAW);
	glEnableVertexAttribArray(2);  // Texture coordinates attribute at location 2
	glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 2 * sizeof(float), (void*)0);

	//bind indicies data
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, surfaceEBO);
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, oceanSurfaces[0]->getIndices().size() * sizeof(unsigned int), oceanSurfaces[0]->getIndices().data(), GL_STATIC_DRAW);

	glBindVertexArray(0);


	//volume buffers
	glGenVertexArrays(1, &volumeVAO);
	glGenBuffers(1, &volumeVBO);
	glGenBuffers(1, &volumeEBO);

	glBindVertexArray(volumeVAO);

	//bind vertex data
	glBindBuffer(GL_ARRAY_BUFFER, volumeVBO);
	glBufferData(GL_ARRAY_BUFFER, oceanVolumes[0]->getVertices().size() * sizeof(glm::vec3), nullptr, GL_DYNAMIC_DRAW);

	//bind incicies data
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, volumeEBO);
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, oceanVolumes[0]->getIndices().size() * sizeof(unsigned int), oceanVolumes[0]->getIndices().data(), GL_STATIC_DRAW);

	glEnableVertexAttribArray(0);
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(float), (void*)0);

	glBindVertexArray(0);
}

bool waterOn = true;

void Application::render() {

	// retrieve the window hieght
	int width, height;
	glfwGetFramebufferSize(m_window, &width, &height);

	m_windowsize = vec2(width, height); // update window size
	glViewport(0, 0, width, height); // set the viewport to draw to the entire window

	// clear the back-buffer
	glClearColor(0.3f, 0.3f, 0.4f, 1.0f);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	// enable flags for normal/forward rendering
	glEnable(GL_DEPTH_TEST);
	glDepthFunc(GL_LESS);

	// projection matrix
	mat4 proj = perspective(1.f, float(width) / height, 0.1f, 1000.f);

	// view matrix
	mat4 view = translate(mat4(1), vec3(0, 0, -m_distance))
		* rotate(mat4(1), m_pitch, vec3(1, 0, 0))
		* rotate(mat4(1), m_yaw, vec3(0, 1, 0));

	m_model.draw(view, proj, false);

	// Update and draw the fish system
	double currentTime = glfwGetTime();
	float deltaTime = static_cast<float>(currentTime - m_lastTime);
	m_lastTime = currentTime;

	m_fishSystem.update(deltaTime);
	m_fishSystem.draw(view, proj);

	glUseProgram(shader);

	// draw terrain
	for (cgra::gl_mesh mesh : terrainModels) {
		terrainGenerator.applyTexture(terrain_texture_path, terrain_normal_map_path);
		mesh.draw(false, 1);
	}


	// Draw instanced plants
	plantGenerator.applyTexture(seaweed_texture_path, seaweed_normal_map_path);
	plantInstance.draw(view, proj, true);

	for (model_group modelGroup : modelsToLoad) {
		for (basic_model model : modelGroup.models) {
			if (modelGroup.name == "rock") {
				rockGenerator.applyTexture(rock_texture_path, rock_normal_map_path);
			}

			model.draw(view, proj, false);
		}
	}
	if (waterOn) {
		glDisable(GL_CULL_FACE);
		glEnable(GL_BLEND);
		glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

		glm::vec3 viewPos = glm::vec3(0, 0, m_distance);

		//render ocean volumes
		glBindVertexArray(volumeVAO);
		for (auto* volume : oceanVolumes) {
			glUseProgram(oceanVolumeShader);
			volume->update(glfwGetTime());
			glBindBuffer(GL_ARRAY_BUFFER, volumeVBO);
			glBufferSubData(GL_ARRAY_BUFFER, 0, volume->getVertices().size() * sizeof(glm::vec3), volume->getVertices().data());
			glUniformMatrix4fv(glGetUniformLocation(oceanVolumeShader, "uProjectionMatrix"), 1, GL_FALSE, value_ptr(proj));
			glUniformMatrix4fv(glGetUniformLocation(oceanVolumeShader, "uViewMatrix"), 1, GL_FALSE, value_ptr(view));
			glDrawElements(GL_TRIANGLES, volume->getIndices().size(), GL_UNSIGNED_INT, 0);
		}
		glBindVertexArray(0);

		//render ocean surfaces
		glBindVertexArray(surfaceVAO);
		for (auto* ocean : oceanSurfaces) {
			glUseProgram(oceanShader);
			ocean->update(glfwGetTime());

			glActiveTexture(GL_TEXTURE0);
			glBindTexture(GL_TEXTURE_2D, foamTexture);
			glUniform1i(glGetUniformLocation(oceanShader, "foamTexture"), 0);

			glBindBuffer(GL_ARRAY_BUFFER, surfaceVBO);
			glBufferSubData(GL_ARRAY_BUFFER, 0, ocean->getVertices().size() * sizeof(glm::vec3), ocean->getVertices().data());
			glUniformMatrix4fv(glGetUniformLocation(oceanShader, "uProjectionMatrix"), 1, GL_FALSE, value_ptr(proj));
			glUniformMatrix4fv(glGetUniformLocation(oceanShader, "uViewMatrix"), 1, GL_FALSE, value_ptr(view));
			glm::vec3 oceanColor(0.0f, 0.1f, 0.3f);
			glUniform3fv(glGetUniformLocation(oceanShader, "uColor"), 1, glm::value_ptr(oceanColor));
			glUniform3fv(glGetUniformLocation(oceanShader, "lightPos"), 1, glm::value_ptr(lightPos));
			glUniform3fv(glGetUniformLocation(oceanShader, "lightColor"), 1, glm::value_ptr(lightColor));
			glUniform3fv(glGetUniformLocation(oceanShader, "viewPos"), 1, glm::value_ptr(viewPos));

			glDrawElements(GL_TRIANGLES, ocean->getIndices().size(), GL_UNSIGNED_INT, 0);
		}
		glBindVertexArray(0);

		if (isUnderwater) {
			glDisable(GL_DEPTH_TEST);
			glUseProgram(oceanVolumeShader);

			glm::mat4 identityMatrix = glm::mat4(1.0f);
			glUniformMatrix4fv(glGetUniformLocation(oceanVolumeShader, "uProjectionMatrix"), 1, GL_FALSE, glm::value_ptr(identityMatrix));
			glUniformMatrix4fv(glGetUniformLocation(oceanVolumeShader, "uViewMatrix"), 1, GL_FALSE, glm::value_ptr(identityMatrix));

			glBindVertexArray(underwaterVAO);
			glDrawElements(GL_TRIANGLES, 6, GL_UNSIGNED_INT, 0);
			glBindVertexArray(0);

			glEnable(GL_DEPTH_TEST);
		}

		glEnable(GL_CULL_FACE);
		glDisable(GL_BLEND);
	}
}

void Application::renderGUI() {

	// setup window
	ImGui::SetNextWindowPos(ImVec2(5, 5), ImGuiSetCond_Once);
	ImGui::SetNextWindowSize(ImVec2(imGuiWindowLength, imGuiWindowHeight), ImGuiSetCond_Once);
	ImGui::Begin("Options", 0);

	// display current camera parameters
	ImGui::Text("Application %.3f ms/frame (%.1f FPS)", 1000.0f / ImGui::GetIO().Framerate, ImGui::GetIO().Framerate);
	ImGui::SliderFloat("Pitch", &m_pitch, -pi<float>() / 2, pi<float>() / 2, "%.2f");
	ImGui::SliderFloat("Yaw", &m_yaw, -pi<float>(), pi<float>(), "%.2f");
	ImGui::SliderFloat("Distance", &m_distance, 0, 100, "%.2f", 2.0f);

	// helpful drawing options
	ImGui::Checkbox("Show axis", &m_show_axis);
	ImGui::SameLine();
	ImGui::Checkbox("Show grid", &m_show_grid);
	ImGui::Checkbox("Wireframe", &m_showWireframe);
	ImGui::SameLine();
	if (ImGui::Button("Screenshot")) rgba_image::screenshot(true);

	ImGui::Separator();
	if (ImGui::CollapsingHeader("Procedural Terrain Generation"))
	{

		ImGui::Text("Perlin Noise Generation");

		ImGui::SliderInt("Size", &noise_size, 10, 1000);
		ImGui::SliderInt("Octaves", &noise_octaves, 1, 10);
		ImGui::SliderFloat("Persistence", &noise_persistence, 0, 1, "%.1f");
		ImGui::SliderFloat("Lacunarity", &noise_lacunarity, 1, 3, "%.1f");
		ImGui::SliderFloat("Amplitude", &noise_amplitude, 0, 1, "%.1f");
		ImGui::SliderFloat("Frequency", &noise_frequency, 0, 2, "%.1f");
		ImGui::SliderFloat("Scale", &noise_scale, 1, 3, "%.1f");

		if (ImGui::Button("Generate Noise")) {
			noiseTexture = terrainGenerator.generateTerrain2D(noise_size, noise_size, noise_octaves, noise_persistence, noise_lacunarity, noise_amplitude, noise_frequency, noise_scale);
			terrainGenerator.applyTexture(terrain_texture_path, terrain_normal_map_path);

			if (auto_generate_terrain) {
				regenerateTerrain();
			}

			if (auto_generate_entire) {
				regeneratePlants();
				regenerateRocks();
			}
		}

		ImGui::SameLine();

		if (ImGui::Button("Reset To Default")) {
			noise_size = 500;
			noise_octaves = 4;
			noise_persistence = 0.5f;
			noise_lacunarity = 2.0f;
			noise_amplitude = 1.0f;
			noise_frequency = 1.0f;
			noise_scale = 1.0;
		}

		ImGui::Text("Generated Noise:");
		ImGui::Image((void*)(intptr_t)noiseTexture, ImVec2(100, 100));

		ImGui::Separator();

		ImGui::Text("Terrain Generation");
		ImGui::SliderInt("Point Spacing", &spacing, 1, 50);
		ImGui::SliderInt("Height Scaling", &heightScaling, 1, 100);
		ImGui::SliderInt("Terrain Height", &terrainOffset, -150, 0);

		/*
		const char* drawingMode[] = { "GL_TRIANGLES", "GL_POINTS", "GL_LINES" };
		int drawing_mode_count = sizeof(drawingMode) / sizeof(drawingMode[0]);


		if (ImGui::Combo("Drawing Mode", &selected_drawing_mode, drawingMode, drawing_mode_count)) {
			GLenum mode = GL_TRIANGLES;

			switch (selected_drawing_mode) {
			case 0:
				mode = GL_TRIANGLES;
				break;
			case 1:
				mode = GL_POINTS;
				break;
			case 2:
				mode = GL_LINES;
				break;
			}

			meshesToLoad.clear();
			terrainGenerator.setDrawingMode(mode);

			terrainGenerator.applyTexture(terrain_texture_path, terrain_normal_map_path);

			gl_mesh terrain = terrainGenerator.generateTerrain3D(spacing, heightScaling, terrainOffset);
			meshesToLoad.push_back(terrain);
		}
		*/

		ImGui::Checkbox("Auto Generate Terrain?", &auto_generate_terrain);
		ImGui::Checkbox("Recalculate Plants And Rocks?", &auto_generate_entire);

		if (ImGui::Button("Generate Terrain From Noise")) {
			regenerateTerrain();

			if (auto_generate_entire) {
				regeneratePlants();
				regenerateRocks();
			}
		}
	}

	if (ImGui::CollapsingHeader("Plant And Rock Generation (L-Systems)"))
	{
		ImGui::Text("Plant Generation");
		ImGui::SliderInt("Iterations Per Plant", &iterations, 1, 6);

		ImGui::SliderInt("Plant Density", &plant_density, 0, 100);
		if (ImGui::SliderFloat2("Plant Scale Range", &plant_scale_range[0], 0.01f, 1.0f, "% 1f")) {
			if (plant_scale_range.x >= plant_scale_range.y) {
				plant_scale_range.y = plant_scale_range.x + 0.01f;
			}
			else if (plant_scale_range.y <= plant_scale_range.x) {
				plant_scale_range.x = plant_scale_range.y - 0.01f;
			}
		}


		if (ImGui::Button("Generate Plants")) regeneratePlants();
		ImGui::SameLine();
		if (ImGui::Button("Unload Plants")) removeMeshesFromRenderList("plant");

		ImGui::Separator();

		ImGui::Text("Rock Generation");
		ImGui::SliderInt("Rock Density", &rock_density, 0, 100);
		if (ImGui::SliderFloat2("Rock Scale Range", &rock_scale_range[0], 0.01f, 1.0f, "% 1f")) {
			if (rock_scale_range.x >= rock_scale_range.y) {
				rock_scale_range.y = rock_scale_range.x + 0.01f;
			}
			else if (rock_scale_range.y <= rock_scale_range.x) {
				rock_scale_range.x = rock_scale_range.y - 0.01f;
			}
		}


		if (ImGui::Button("Generate Rocks")) regenerateRocks();
		ImGui::SameLine();
		if (ImGui::Button("Unload Rocks")) removeMeshesFromRenderList("rock");

	}

	ImGui::Separator();
	if (ImGui::CollapsingHeader("Ocean Wave Settings")) {
		static float amplitudeScale = 1.0f;
		static float speedScale = 1.0f;
		static float wavelengthScale = 1.0f;

		//amplitude slider
		ImGui::SliderFloat("Wave Amplitude", &amplitudeScale, 0.0f, 2.0f, "%.2f");

		//speed slider
		ImGui::SliderFloat("Wave Speed", &speedScale, 0.0f, 2.0f, "%.2f");

		//wavelength slider
		ImGui::SliderFloat("Wave Wavelength", &wavelengthScale, 0.0f, 2.0f, "%.2f");

		//apply changes over surfaces and volumes
		for (auto* ocean : oceanSurfaces) {
			ocean->setAmplitudeScale(amplitudeScale);
			ocean->setSpeedScale(speedScale);
			ocean->setWavelengthScale(wavelengthScale);
		}
		for (auto* volume : oceanVolumes) {
			volume->setAmplitudeScale(amplitudeScale);
			volume->setSpeedScale(speedScale);
			volume->setWavelengthScale(wavelengthScale);
		}

		//change camera positions to above or below water
		if (ImGui::Button("Toggle Underwater View")) {
			isUnderwater = !isUnderwater;
		}

		if (ImGui::Button("Turn off water")) {
			waterOn = !waterOn;
		}

		ImGui::Separator();
		ImGui::Text("Lighting");
		ImGui::SliderFloat("Sun Position", &lightPos.x, -300.0f, 300.0f);
	}

	ImGui::End();
}

void Application::cursorPosCallback(double xpos, double ypos) {
	if (m_leftMouseDown) {
		vec2 whsize = m_windowsize / 2.0f;

		// clamp the pitch to [-pi/2, pi/2]
		m_pitch += float(acos(glm::clamp((m_mousePosition.y - whsize.y) / whsize.y, -1.0f, 1.0f))
			- acos(glm::clamp((float(ypos) - whsize.y) / whsize.y, -1.0f, 1.0f)));
		m_pitch = float(glm::clamp(m_pitch, -pi<float>() / 2, pi<float>() / 2));

		// wrap the yaw to [-pi, pi]
		m_yaw += float(acos(glm::clamp((m_mousePosition.x - whsize.x) / whsize.x, -1.0f, 1.0f))
			- acos(glm::clamp((float(xpos) - whsize.x) / whsize.x, -1.0f, 1.0f)));
		if (m_yaw > pi<float>()) m_yaw -= float(2 * pi<float>());
		else if (m_yaw < -pi<float>()) m_yaw += float(2 * pi<float>());
	}

	// updated mouse position
	m_mousePosition = vec2(xpos, ypos);
}


void Application::mouseButtonCallback(int button, int action, int mods) {
	(void)mods; // currently un-used

	// capture is left-mouse down
	if (button == GLFW_MOUSE_BUTTON_LEFT)
		m_leftMouseDown = (action == GLFW_PRESS); // only other option is GLFW_RELEASE
}


void Application::scrollCallback(double xoffset, double yoffset) {
	(void)xoffset; // currently un-used
	m_distance *= pow(1.1f, -yoffset);
}


void Application::keyCallback(int key, int scancode, int action, int mods) {
	(void)key, (void)scancode, (void)action, (void)mods; // currently un-used
}


void Application::charCallback(unsigned int c) {
	(void)c; // currently un-used
}

void Application::removeMeshesFromRenderList(string name) {
	if (name == "plant") {
		plantInstance.numInstances = 0;
	}
	else if (name == "terrain") {
		terrainModels.clear();
	}
	else {

		modelsToLoad.erase(
			std::remove_if(modelsToLoad.begin(), modelsToLoad.end(),
				[&name](const model_group& group) {
					return group.name == name;
				}),
			modelsToLoad.end()
		);
	}
}

void Application::regenerateTerrain() {
	terrainModels.clear();
	terrainGenerator.applyTexture(terrain_texture_path, terrain_normal_map_path);

	gl_mesh terrain = terrainGenerator.generateTerrain3D(spacing, heightScaling, terrainOffset);
	terrainModels.push_back(terrain);
}

void Application::regeneratePlants() {
	plantGenerator.applyTexture(seaweed_texture_path, seaweed_normal_map_path);
	plantInstance = plantGenerator.generateAndPlacePlants(iterations, branch_length, terrainGenerator, plant_density, plant_scale_range);
}

void Application::regenerateRocks() {
	removeMeshesFromRenderList("rock");
	vector<basic_model> generatedRocks = rockGenerator.generateRocks(rock_paths, terrainGenerator, rock_density, rock_scale_range);
	modelsToLoad.push_back({ "rock", generatedRocks });
}