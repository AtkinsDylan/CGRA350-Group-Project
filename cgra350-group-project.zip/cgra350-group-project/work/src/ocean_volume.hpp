#pragma once

#include <glm/glm.hpp>
#include <vector>

namespace cgra {

    class OceanVolume {
    private:
        int grid_size;
        float wave_amplitude;
        float wind_speed;
        float depth;
        float scalingFactor;
        std::vector<glm::vec3> vertices;
        std::vector<unsigned int> indices;
        glm::vec2 offset;
        bool drawLeft, drawRight, drawTop, drawBottom;
        float amplitudeScale = 1.0f;
        float speedScale = 1.0f;
        float wavelengthScale = 1.0f;

    public:
        OceanVolume(int grid_size, float wave_amplitude, float wind_speed, float depth, glm::vec2 offset, bool drawLeft, bool drawRight, bool drawTop, bool drawBottom, float scalingFactor);
        std::vector<glm::vec3> getVertices() const;
        std::vector<unsigned int> getIndices() const;
        std::vector<glm::vec3> getNormals() const;
        void update(float time);
        void setAmplitudeScale(float scale) { amplitudeScale = scale; }
        void setSpeedScale(float scale) { speedScale = scale; }
        void setWavelengthScale(float scale) { wavelengthScale = scale; }
        void setOffset(glm::vec2 newOffset);
    };

}
